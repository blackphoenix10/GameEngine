#pragma once

#ifdef WIN32
	#include <Windows.h>
#endif

#include <string>

#include "Core/Core.h"
