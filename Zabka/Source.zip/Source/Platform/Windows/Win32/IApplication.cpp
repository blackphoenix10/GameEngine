#include "Zabka.h"
#include "IApplication.h"

namespace Win32 {
	IApplication::IApplication()
	{
	}
}
