#pragma once

namespace CmdLineArgs {

	VOID ZABKA_API ReadArguments();
	VOID ZABKA_API ReadArgument(CONST WCHAR* argument);
}